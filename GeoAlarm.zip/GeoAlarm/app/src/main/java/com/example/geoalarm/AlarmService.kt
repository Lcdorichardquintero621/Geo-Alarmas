package com.example.geoalarm

import android.app.*
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.os.IBinder

class AlarmService : Service() {
    companion object {
        // true mientras la alarma está sonando (lo lee la interfaz)
        var ringing by mutableStateOf(false)
    }

    private var player: MediaPlayer? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("alarm", "Alarma", NotificationManager.IMPORTANCE_HIGH)
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, AlarmService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "alarm")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("¡Llegaste a tu destino!")
            .setContentText("Toca para detener la alarma")
            .setFullScreenIntent(open, true)
            .addAction(Notification.Action.Builder(null, "Detener", stop).build())
            .setOngoing(true)
            .build()
        startForeground(1, n)

        player?.release()
        player = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            val uri = AlarmStore.audio(this@AlarmService)
            if (uri != null) setDataSource(this@AlarmService, Uri.parse(uri))
            else setDataSource(this@AlarmService,
                android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI)
            isLooping = true
            prepare()
            start()
        }
        ringing = true
        return START_NOT_STICKY
    }

    override fun onDestroy() { player?.release(); ringing = false; super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null
}
