package com.example.geoalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// Tras reiniciar el teléfono Android borra las geovallas: se vuelven a registrar las de las alarmas activas.
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmStore.activeAlarms(context).forEach { GeofenceHelper.register(context, it) }
    }
}
