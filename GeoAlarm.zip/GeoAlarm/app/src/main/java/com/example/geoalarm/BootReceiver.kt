package com.example.geoalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// Tras reiniciar el teléfono Android borra las geovallas: se vuelve a registrar la de respaldo.
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!AlarmStore.isActivePersisted(context)) return
        val p = AlarmStore.place(context) ?: return
        GeofenceHelper.register(context, p.first, p.second, p.third)
    }
}
