package com.example.geoalarm

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices

// La geovalla es el RESPALDO: el seguimiento por GPS (TrackingService) es el principal.
object GeofenceHelper {
    private const val ID = "destino"

    @SuppressLint("MissingPermission")
    fun register(ctx: Context, lat: Double, lon: Double, radius: Float) {
        try {
            val geofence = Geofence.Builder()
                .setRequestId(ID)
                .setCircularRegion(lat, lon, radius)
                .setExpirationDuration(Geofence.NEVER_EXPIRE)
                .setNotificationResponsiveness(0)
                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
                .build()
            val request = GeofencingRequest.Builder()
                .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
                .addGeofence(geofence).build()
            val pi = PendingIntent.getBroadcast(
                ctx, 0, Intent(ctx, GeofenceReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            val client = LocationServices.getGeofencingClient(ctx)
            client.removeGeofences(pi)
            client.addGeofences(request, pi)
        } catch (e: Exception) {
            // Si falla, el seguimiento por GPS sigue funcionando
        }
    }

    fun remove(ctx: Context) {
        try { LocationServices.getGeofencingClient(ctx).removeGeofences(listOf(ID)) }
        catch (e: Exception) { }
    }
}
