package com.example.geoalarm

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices

// La geovalla es el RESPALDO: el seguimiento por GPS (TrackingService) es el principal.
// Cada alarma tiene su propia geovalla (el id de la alarma es el id de la geovalla).
object GeofenceHelper {
    @SuppressLint("MissingPermission")
    fun register(ctx: Context, a: Alarm) {
        try {
            val geofence = Geofence.Builder()
                .setRequestId(a.id)
                .setCircularRegion(a.lat, a.lon, a.radius)
                .setExpirationDuration(Geofence.NEVER_EXPIRE)
                .setNotificationResponsiveness(0)
                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
                .build()
            val request = GeofencingRequest.Builder()
                .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
                .addGeofence(geofence).build()
            val pi = PendingIntent.getBroadcast(
                ctx, 0, Intent(ctx, GeofenceReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            // Si ya existe una geovalla con ese id, se reemplaza
            LocationServices.getGeofencingClient(ctx).addGeofences(request, pi)
        } catch (e: Exception) {
            // Si falla, el seguimiento por GPS sigue funcionando
        }
    }

    fun remove(ctx: Context, id: String) {
        try { LocationServices.getGeofencingClient(ctx).removeGeofences(listOf(id)) }
        catch (e: Exception) { }
    }
}
