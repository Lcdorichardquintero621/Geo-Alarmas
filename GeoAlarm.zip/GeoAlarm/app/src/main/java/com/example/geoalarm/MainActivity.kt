package com.example.geoalarm

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

// Identificación de la app ante los servidores de OpenStreetMap (obligatorio por su política de uso)
const val APP_USER_AGENT =
    "GeoAlarma/1.0 (Android; alarma por ubicacion; uso personal; https://github.com/Lcdorichardquintero621/Geo-Alarmas)"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().apply {
            userAgentValue = APP_USER_AGENT
            tileDownloadThreads = 2
            tileFileSystemThreads = 2
            osmdroidBasePath = File(cacheDir, "osmdroid")
            osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
        }
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        AlarmStore.load(this)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        setContent { GeoTheme { Screen() } }
    }
}

data class Stop(val lat: Double, val lon: Double, val name: String)

private val Red = Color(0xFFD32F2F)

@SuppressLint("MissingPermission")
@Composable
fun Screen() {
    val ctx = LocalContext.current

    // Estado que se conserva entre aperturas de la app
    val saved = remember { AlarmStore.place(ctx) }
    var target by remember {
        mutableStateOf(if (AlarmStore.active && saved != null) GeoPoint(saved.first, saved.second) else null)
    }
    var targetName by remember { mutableStateOf<String?>(null) }
    var radius by remember { mutableStateOf(if (AlarmStore.active && saved != null) saved.third else 50f) }
    var audio by remember { mutableStateOf(AlarmStore.audio(ctx)?.let { Uri.parse(it) }) }
    val audioName = remember(audio) { audio?.let { audioDisplayName(ctx, it) } }
    val favs = remember { mutableStateListOf<Fav>().apply { addAll(AlarmStore.favs(ctx)) } }

    var showFavs by remember { mutableStateOf(false) }
    var favName by remember { mutableStateOf("") }
    var centerReq by remember { mutableStateOf<Pair<GeoPoint, Int>?>(null) }
    var reqN by remember { mutableStateOf(0) }
    var hasLoc by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    fun centerOn(p: GeoPoint) { reqN++; centerReq = Pair(p, reqN) }

    fun goToMyLocation() {
        LocationServices.getFusedLocationProviderClient(ctx)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { l -> if (l != null) centerOn(GeoPoint(l.latitude, l.longitude)) }
    }

    val locPerm = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok -> hasLoc = ok; if (ok) goToMyLocation() }

    LaunchedEffect(Unit) {
        if (hasLoc) goToMyLocation() else locPerm.launch(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    LaunchedEffect(showFavs) { if (showFavs) favName = targetName ?: "" }

    val pickAudio = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            AlarmStore.saveAudio(ctx, uri.toString())   // queda guardado hasta que lo cambies
            audio = uri
        }
    }

    val bgPerm = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        if (!ok) Toast.makeText(
            ctx, "Recomendado: permite la ubicación 'Siempre' en Ajustes para mayor seguridad",
            Toast.LENGTH_LONG
        ).show()
        activate(ctx, target!!, audio!!, radius)
    }

    val fgPerms = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { r ->
        if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            hasLoc = true
            if (Build.VERSION.SDK_INT >= 29) bgPerm.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            else activate(ctx, target!!, audio!!, radius)
        }
    }

    Column(Modifier.fillMaxSize().background(Blue50)) {
        // Cabecera con degradado azul, icono + nombre
        Row(
            Modifier.fillMaxWidth()
                .zIndex(1f)
                .background(Brush.horizontalGradient(listOf(Blue900, Blue500)))
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(R.drawable.ic_logo),
                contentDescription = "Icono Geo-Alarma",
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(11.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Geo-Alarma", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Te aviso cuando llegues", color = Blue50, fontSize = 13.sp)
            }
        }

        // clipToBounds: el mapa no se sale de su cuadro al hacer zoom
        Box(Modifier.weight(1f).clipToBounds()) {
            OsmMap(
                modifier = Modifier.fillMaxSize(),
                target = target,
                radius = radius,
                centerReq = centerReq,
                hasLocation = hasLoc,
                onTap = { p, name -> target = p; targetName = name }
            )
            SmallFloatingActionButton(
                onClick = {
                    if (hasLoc) goToMyLocation() else locPerm.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                },
                containerColor = Color.White,
                contentColor = Blue500,
                modifier = Modifier.align(Alignment.BottomStart).padding(12.dp)
            ) { Text("◎", fontSize = 22.sp) }
        }

        // Panel inferior redondeado
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(Color.White)
                .navigationBarsPadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                when {
                    AlarmStore.active -> "Alarma activa ✓ (sonará al llegar)"
                    target == null -> "Toca el mapa o un paradero para elegir el lugar"
                    else -> "Lugar elegido ✓"
                },
                color = Blue900, fontWeight = FontWeight.SemiBold
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Radio: ${radius.toInt()} m", color = Blue700, fontWeight = FontWeight.Medium,
                    maxLines = 1, modifier = Modifier.width(120.dp))
                Slider(
                    value = radius,
                    onValueChange = { radius = it.toInt().coerceIn(1, 100).toFloat() },
                    valueRange = 1f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = Blue500, activeTrackColor = Blue500,
                        inactiveTrackColor = Blue50
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(
                    onClick = { showFavs = true },
                    modifier = Modifier.weight(1f)
                ) { Text("★ Guardados", maxLines = 1) }
                FilledTonalButton(
                    onClick = { pickAudio.launch(arrayOf("audio/*")) },
                    modifier = Modifier.weight(1f)
                ) { Text(if (audio == null) "Elegir sonido" else "Cambiar sonido", maxLines = 1) }
            }
            Text(
                if (audio == null) "Aún no has elegido un sonido"
                else "Sonido guardado: ${audioName ?: "archivo de audio"}",
                fontSize = 12.sp, color = Color.Gray,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )

            when {
                AlarmService.ringing -> Button(
                    onClick = { ctx.stopService(Intent(ctx, AlarmService::class.java)) },
                    colors = ButtonDefaults.buttonColors(containerColor = Red),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("Detener alarma", fontSize = 16.sp, fontWeight = FontWeight.Bold) }

                AlarmStore.active -> OutlinedButton(
                    onClick = {
                        GeofenceHelper.remove(ctx)
                        AlarmStore.setActive(ctx, false)
                        TrackingService.stop(ctx)
                        Toast.makeText(ctx, "Alarma desactivada", Toast.LENGTH_SHORT).show()
                    },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("Desactivar alarma", fontSize = 16.sp, color = Red, fontWeight = FontWeight.Bold) }

                else -> Button(
                    enabled = target != null && audio != null,
                    onClick = {
                        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
                        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
                        fgPerms.launch(perms.toTypedArray())
                    },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("Activar alarma", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }

    // Lugares y paraderos frecuentes
    if (showFavs) {
        AlertDialog(
            onDismissRequest = { showFavs = false },
            confirmButton = { TextButton(onClick = { showFavs = false }) { Text("Cerrar") } },
            title = { Text("Lugares guardados") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (favs.isEmpty()) {
                        Text(
                            "Aún no tienes lugares guardados. Toca un paradero o un punto del mapa y guárdalo aquí.",
                            fontSize = 13.sp, color = Color.Gray
                        )
                    }
                    LazyColumn(Modifier.heightIn(max = 220.dp)) {
                        items(favs) { f ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable {
                                        val p = GeoPoint(f.lat, f.lon)
                                        target = p; targetName = f.name
                                        centerOn(p)
                                        showFavs = false
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "★ ${f.name}", Modifier.weight(1f), color = Blue900,
                                    fontWeight = FontWeight.Medium, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                TextButton(onClick = {
                                    AlarmStore.removeFav(ctx, f.name)
                                    favs.remove(f)
                                }) { Text("Borrar", color = Red) }
                            }
                        }
                    }
                    HorizontalDivider()
                    if (target == null) {
                        Text(
                            "Para guardar un lugar, primero tócalo en el mapa o toca un paradero.",
                            fontSize = 12.sp, color = Color.Gray
                        )
                    }
                    OutlinedTextField(
                        value = favName,
                        onValueChange = { favName = it },
                        label = { Text("Nombre del lugar") },
                        singleLine = true,
                        enabled = target != null,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        enabled = target != null && favName.isNotBlank(),
                        onClick = {
                            val f = Fav(favName.trim(), target!!.latitude, target!!.longitude)
                            AlarmStore.addFav(ctx, f)
                            favs.removeAll { it.name == f.name }
                            favs.add(f)
                            favName = ""
                            Toast.makeText(ctx, "Lugar guardado", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Guardar lugar elegido") }
                }
            }
        )
    }
}

@Composable
fun OsmMap(
    modifier: Modifier,
    target: GeoPoint?,
    radius: Float,
    centerReq: Pair<GeoPoint, Int>?,
    hasLocation: Boolean,
    onTap: (GeoPoint, String?) -> Unit
) {
    val ctx = LocalContext.current
    val mapView = remember {
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)   // calles con nombre
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.SHOW_AND_FADEOUT)
            controller.setZoom(16.0)
            controller.setCenter(GeoPoint(4.65, -74.08))
        }
    }
    val myLoc = remember { MyLocationNewOverlay(GpsMyLocationProvider(ctx), mapView) }
    val currentOnTap by rememberUpdatedState(onTap)
    var stops by remember { mutableStateOf(listOf<Stop>()) }
    var tick by remember { mutableStateOf(0) }

    DisposableEffect(mapView) {
        mapView.onResume()
        val l = object : MapListener {
            override fun onScroll(event: ScrollEvent?): Boolean { tick++; return false }
            override fun onZoom(event: ZoomEvent?): Boolean { tick++; return false }
        }
        mapView.addMapListener(l)
        onDispose {
            mapView.removeMapListener(l)
            mapView.onPause()
            mapView.onDetach()
        }
    }

    // Punto azul con tu ubicación
    DisposableEffect(hasLocation) {
        if (hasLocation) {
            myLoc.enableMyLocation()
            if (!mapView.overlays.contains(myLoc)) mapView.overlays.add(myLoc)
        }
        onDispose { myLoc.disableMyLocation() }
    }

    LaunchedEffect(centerReq) {
        centerReq?.let {
            mapView.controller.setZoom(17.0)
            mapView.controller.animateTo(it.first)
        }
    }

    // Paraderos de la zona visible (se cargan al acercar el mapa)
    LaunchedEffect(tick) {
        delay(700)
        if (mapView.zoomLevelDouble < 15.0) { stops = emptyList(); return@LaunchedEffect }
        val bb = mapView.boundingBox
        stops = withContext(Dispatchers.IO) { fetchStops(bb) }
    }

    AndroidView(
        modifier = modifier,
        factory = {
            mapView.overlays.add(0, MapEventsOverlay(object : MapEventsReceiver {
                override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                    currentOnTap(p, null); return true
                }
                override fun longPressHelper(p: GeoPoint): Boolean = false
            }))
            mapView
        },
        update = { mv ->
            mv.overlays.filter { it is Marker || it is Polygon }.forEach { mv.overlays.remove(it) }

            val icon = stopIcon(mv.context)
            stops.forEach { s ->
                mv.overlays.add(Marker(mv).apply {
                    position = GeoPoint(s.lat, s.lon)
                    title = s.name
                    setIcon(icon)
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                    // Tocar un paradero lo elige como destino
                    setOnMarkerClickListener { m, _ ->
                        currentOnTap(m.position, s.name)
                        m.showInfoWindow()
                        true
                    }
                })
            }
            target?.let { t ->
                mv.overlays.add(Polygon(mv).apply {
                    points = Polygon.pointsAsCircle(t, radius.toDouble())
                    fillPaint.color = 0x331E88E5
                    outlinePaint.color = 0xFF1E88E5.toInt()
                    outlinePaint.strokeWidth = 4f
                })
                mv.overlays.add(Marker(mv).apply {
                    position = t
                    title = "Destino"
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                })
            }
            mv.invalidate()
        }
    )
}

private fun stopIcon(ctx: Context): Drawable {
    val size = (ctx.resources.displayMetrics.density * 18).toInt()
    return GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(0xFFFF9800.toInt())
        setStroke(3, 0xFFFFFFFF.toInt())
        setSize(size, size)
    }
}

private fun audioDisplayName(ctx: Context, uri: Uri): String? = try {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    }
} catch (e: Exception) { null }

// Paraderos de bus desde OpenStreetMap (Overpass API, gratis y sin clave)
private fun fetchStops(bb: BoundingBox): List<Stop> = try {
    val q = "[out:json][timeout:15];" +
        "node[\"highway\"=\"bus_stop\"](${bb.latSouth},${bb.lonWest},${bb.latNorth},${bb.lonEast});" +
        "out 150;"
    val url = URL("https://overpass-api.de/api/interpreter?data=" + URLEncoder.encode(q, "UTF-8"))
    val c = url.openConnection() as HttpURLConnection
    c.connectTimeout = 10000
    c.readTimeout = 15000
    c.setRequestProperty("User-Agent", APP_USER_AGENT)
    val body = c.inputStream.bufferedReader().use { it.readText() }
    val arr = JSONObject(body).getJSONArray("elements")
    (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        val name = o.optJSONObject("tags")?.optString("name", "")?.takeIf { it.isNotBlank() } ?: "Paradero"
        Stop(o.getDouble("lat"), o.getDouble("lon"), name)
    }
} catch (e: Exception) {
    emptyList()
}

@SuppressLint("BatteryLife")
private fun activate(ctx: Context, p: GeoPoint, audio: Uri, radius: Float) {
    AlarmStore.savePlace(ctx, p.latitude, p.longitude, radius)
    AlarmStore.saveAudio(ctx, audio.toString())
    AlarmStore.setActive(ctx, true)

    // Principal: GPS en un servicio en primer plano (funciona con otras apps y pantalla apagada)
    TrackingService.start(ctx)
    // Respaldo: geovalla de Google
    GeofenceHelper.register(ctx, p.latitude, p.longitude, radius)

    // Pide que Android no "duerma" la app para ahorrar batería (solo si aún no está permitido)
    try {
        val pm = ctx.getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(ctx.packageName)) {
            ctx.startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
            )
        }
    } catch (e: Exception) { }
    Toast.makeText(ctx, "Alarma activada", Toast.LENGTH_SHORT).show()
}
