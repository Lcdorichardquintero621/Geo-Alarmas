package com.example.geoalarm

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.maps.android.compose.*

// Estilo que fuerza nombres de calles y paraderos de transporte
private const val TRANSIT_STYLE = """[
 {"featureType":"road","elementType":"labels.text","stylers":[{"visibility":"on"}]},
 {"featureType":"transit.station.bus","stylers":[{"visibility":"on"}]},
 {"featureType":"transit.station","stylers":[{"visibility":"on"}]},
 {"featureType":"poi.business","stylers":[{"visibility":"off"}]}
]"""

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        setContent { GeoTheme { Screen() } }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun Screen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var target by remember { mutableStateOf<LatLng?>(null) }
    var audio by remember { mutableStateOf<Uri?>(null) }
    var transit by remember { mutableStateOf(true) }
    var radius by remember { mutableStateOf(50f) }
    val diag = remember { diagnostics(ctx) }
    val camera = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(4.65, -74.08), 15f)
    }

    val pickAudio = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            audio = uri
        }
    }

    val bgPerm = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        if (ok) activate(ctx, target!!, audio!!, radius)
        else Toast.makeText(ctx, "Debes permitir la ubicación 'Siempre'", Toast.LENGTH_LONG).show()
    }

    val fgPerms = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { r ->
        if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            if (Build.VERSION.SDK_INT >= 29) bgPerm.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            else activate(ctx, target!!, audio!!, radius)
        }
    }

    Column(Modifier.fillMaxSize().background(Blue50)) {
        // Cabecera con degradado azul, icono + nombre
        Row(
            Modifier.fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(Blue900, Blue500)))
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(R.drawable.ic_logo),
                contentDescription = "Icono Geo-Alarma",
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(11.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Geo-Alarma", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Te aviso cuando llegues", color = Blue50, fontSize = 13.sp)
            }
        }

        Box(Modifier.weight(1f)) {
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = camera,
                properties = MapProperties(
                    mapStyleOptions = if (transit) MapStyleOptions(TRANSIT_STYLE) else null
                ),
                onMapClick = { target = it }
            ) {
                target?.let {
                    Marker(state = MarkerState(it))
                    Circle(
                        center = it, radius = radius.toDouble(),
                        fillColor = Color(0x331E88E5), strokeColor = Blue500, strokeWidth = 4f
                    )
                }
            }
        }

        // Panel inferior redondeado
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(Color.White)
                .navigationBarsPadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                if (target == null) "Toca el mapa para elegir el lugar"
                else "Lugar elegido ✓",
                color = Blue900, fontWeight = FontWeight.SemiBold
            )
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text("Radio: ${radius.toInt()} m", color = Blue700, fontWeight = FontWeight.Medium,
                    modifier = Modifier.width(96.dp))
                Slider(
                    value = radius,
                    onValueChange = { radius = it.toInt().coerceIn(1, 100).toFloat() },
                    valueRange = 1f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = Blue500, activeTrackColor = Blue500,
                        inactiveTrackColor = Blue50
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(
                    onClick = { transit = !transit },
                    modifier = Modifier.weight(1f)
                ) { Text(if (transit) "Calles y paraderos" else "Mapa normal") }
                FilledTonalButton(
                    onClick = { pickAudio.launch(arrayOf("audio/*")) },
                    modifier = Modifier.weight(1f)
                ) { Text(if (audio == null) "Elegir sonido" else "Sonido ✓") }
            }
            Text(diag, fontSize = 11.sp, color = Color.Gray)
            Button(
                enabled = target != null && audio != null,
                onClick = {
                    val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
                    if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
                    fgPerms.launch(perms.toTypedArray())
                },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Activar alarma", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@SuppressLint("MissingPermission")
private fun activate(ctx: Context, p: LatLng, audio: Uri, radius: Float) {
    AlarmStore.save(ctx, p.latitude, p.longitude, audio.toString())

    val geofence = Geofence.Builder()
        .setRequestId("destino")
        .setCircularRegion(p.latitude, p.longitude, radius)
        .setExpirationDuration(Geofence.NEVER_EXPIRE)
        .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
        .build()
    val request = GeofencingRequest.Builder()
        .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
        .addGeofence(geofence).build()
    val pi = PendingIntent.getBroadcast(
        ctx, 0, Intent(ctx, GeofenceReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
    )
    val client = LocationServices.getGeofencingClient(ctx)
    client.removeGeofences(pi)
    client.addGeofences(request, pi)
        .addOnSuccessListener { Toast.makeText(ctx, "Alarma activada", Toast.LENGTH_SHORT).show() }
        .addOnFailureListener { Toast.makeText(ctx, "Error: ${it.message}", Toast.LENGTH_LONG).show() }
}


private fun diagnostics(ctx: Context): String {
    val key = try {
        ctx.packageManager.getApplicationInfo(ctx.packageName, PackageManager.GET_META_DATA)
            .metaData?.getString("com.google.android.geo.API_KEY") ?: ""
    } catch (e: Exception) { "" }
    val keyText = if (key.isBlank() || key.startsWith("TU_API"))
        "Clave de Maps: NO configurada"
    else "Clave de Maps: ${key.take(4)}...${key.takeLast(4)} (${key.length} caracteres)"
    val code = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(ctx)
    val gms = if (code == ConnectionResult.SUCCESS) "OK" else "problema (código $code)"
    return "$keyText  |  Google Play Services: $gms"
}
