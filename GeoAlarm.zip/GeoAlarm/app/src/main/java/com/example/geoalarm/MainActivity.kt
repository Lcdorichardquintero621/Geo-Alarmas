package com.example.geoalarm

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

// Identificación de la app ante los servidores de OpenStreetMap (obligatorio por su política de uso)
const val APP_USER_AGENT =
    "GeoAlarma/1.2 (Android; alarma por ubicacion; uso personal; https://github.com/Lcdorichardquintero621/Geo-Alarmas)"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().apply {
            userAgentValue = APP_USER_AGENT
            tileDownloadThreads = 2
            tileFileSystemThreads = 2
            osmdroidBasePath = File(cacheDir, "osmdroid")
            osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
        }
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        AlarmStore.load(this)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        setContent { GeoTheme { Screen() } }
    }
}

data class Stop(val lat: Double, val lon: Double, val name: String)

// Resultado del buscador (paraderos cercanos y lugares/calles de OpenStreetMap)
data class PlaceHit(val name: String, val detail: String, val lat: Double, val lon: Double, val stop: Boolean)
data class SearchResult(val places: List<PlaceHit>, val failed: Boolean)

private val Red = Color(0xFFD32F2F)

@SuppressLint("MissingPermission")
@Composable
fun Screen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current

    // Lugar que se está eligiendo ahora (todavía no es una alarma)
    var target by remember { mutableStateOf<GeoPoint?>(null) }
    var targetName by remember { mutableStateOf<String?>(null) }
    var radius by remember { mutableStateOf(100f) }
    var audio by remember { mutableStateOf(AlarmStore.audio(ctx)?.let { Uri.parse(it) }) }
    val audioName = remember(audio) { audio?.let { audioDisplayName(ctx, it) } }
    val favs = remember { mutableStateListOf<Fav>().apply { addAll(AlarmStore.favs(ctx)) } }

    val alarms = AlarmStore.alarms
    val activeCount = alarms.count { it.active }

    var showFavs by remember { mutableStateOf(false) }
    var showAlarms by remember { mutableStateOf(false) }
    var favName by remember { mutableStateOf("") }
    var centerReq by remember { mutableStateOf<Pair<GeoPoint, Int>?>(null) }
    var reqN by remember { mutableStateOf(0) }
    var mapRef by remember { mutableStateOf<MapView?>(null) }
    var hasLoc by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    // Buscador
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf(listOf<PlaceHit>()) }
    var searching by remember { mutableStateOf(false) }
    var searchMsg by remember { mutableStateOf<String?>(null) }

    fun granted(perm: String) =
        ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

    fun centerOn(p: GeoPoint) { reqN++; centerReq = Pair(p, reqN) }

    fun goToMyLocation() {
        LocationServices.getFusedLocationProviderClient(ctx)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { l -> if (l != null) centerOn(GeoPoint(l.latitude, l.longitude)) }
    }

    fun doSearch() {
        val q = query.trim()
        if (q.length < 2) return
        focus.clearFocus()
        searching = true; searchMsg = null; results = emptyList()
        val box = mapRef?.boundingBox
        scope.launch {
            val r = withContext(Dispatchers.IO) { searchPlaces(q, box) }
            results = r.places
            searchMsg = when {
                r.failed -> "No se pudo buscar. Revisa tu conexión a internet"
                r.places.isEmpty() -> "Sin resultados para \"$q\""
                else -> null
            }
            searching = false
        }
    }

    fun pickPlace(h: PlaceHit) {
        val p = GeoPoint(h.lat, h.lon)
        target = p; targetName = h.name
        results = emptyList(); searchMsg = null
        centerOn(p)
    }

    // Crea una alarma nueva con el lugar elegido; las demás siguen como estaban
    fun commitAdd() {
        val t = target ?: return
        val a = Alarm(
            id = System.currentTimeMillis().toString(),
            name = targetName ?: "Alarma ${alarms.size + 1}",
            lat = t.latitude, lon = t.longitude, radius = radius,
            audio = audio?.toString(), active = true
        )
        addAlarm(ctx, a)
        target = null; targetName = null
    }

    fun toggleAlarm(a: Alarm, on: Boolean) {
        if (on) {
            if (!granted(Manifest.permission.ACCESS_FINE_LOCATION)) {
                Toast.makeText(ctx, "Falta el permiso de ubicación", Toast.LENGTH_LONG).show()
                return
            }
            AlarmStore.setActive(ctx, a.id, true)
            TrackingService.start(ctx)
            GeofenceHelper.register(ctx, a.copy(active = true))
        } else {
            AlarmStore.setActive(ctx, a.id, false)
            GeofenceHelper.remove(ctx, a.id)
            TrackingService.refresh(ctx)
        }
    }

    fun deleteAlarm(a: Alarm) {
        AlarmStore.remove(ctx, a.id)
        GeofenceHelper.remove(ctx, a.id)
        TrackingService.refresh(ctx)
    }

    val locPerm = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok -> hasLoc = ok; if (ok) goToMyLocation() }

    LaunchedEffect(Unit) {
        if (hasLoc) goToMyLocation() else locPerm.launch(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    LaunchedEffect(showFavs) { if (showFavs) favName = targetName ?: "" }

    val pickAudio = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            AlarmStore.saveAudio(ctx, uri.toString())   // queda guardado para las próximas alarmas
            audio = uri
        }
    }

    val bgPerm = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        if (!ok) Toast.makeText(
            ctx, "Recomendado: permite la ubicación 'Siempre' en Ajustes para mayor seguridad",
            Toast.LENGTH_LONG
        ).show()
        commitAdd()
    }

    fun proceed() {
        if (Build.VERSION.SDK_INT >= 29 &&
            !granted(Manifest.permission.ACCESS_BACKGROUND_LOCATION) &&
            AlarmStore.firstTime(ctx, "bg")
        ) bgPerm.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        else commitAdd()
    }

    val fgPerms = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        if (granted(Manifest.permission.ACCESS_FINE_LOCATION)) {
            hasLoc = true
            proceed()
        } else {
            Toast.makeText(ctx, "Se necesita el permiso de ubicación para la alarma", Toast.LENGTH_LONG).show()
        }
    }

    Column(Modifier.fillMaxSize().background(Blue50)) {
        // Cabecera con degradado azul, icono + nombre
        Row(
            Modifier.fillMaxWidth()
                .zIndex(1f)
                .background(Brush.horizontalGradient(listOf(Blue900, Blue500)))
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(R.drawable.ic_logo),
                contentDescription = "Icono Geo-Alarma",
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(11.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Geo-Alarma", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Te aviso cuando llegues", color = Blue50, fontSize = 13.sp)
            }
        }

        // clipToBounds: el mapa no se sale de su cuadro al hacer zoom
        Box(Modifier.weight(1f).clipToBounds()) {
            OsmMap(
                modifier = Modifier.fillMaxSize(),
                target = target,
                radius = radius,
                alarms = alarms,
                centerReq = centerReq,
                hasLocation = hasLoc,
                onMapView = { mapRef = it },
                onTap = { p, name ->
                    target = p; targetName = name
                    results = emptyList(); searchMsg = null
                    // Si tocaste un punto sin nombre, se busca el nombre de la calle
                    if (name == null) scope.launch {
                        val n = withContext(Dispatchers.IO) { reverseName(p.latitude, p.longitude) }
                        if (n != null && target == p) targetName = n
                    }
                }
            )

            // Buscador: paraderos, calles o cualquier lugar
            Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(10.dp)) {
                Surface(shape = RoundedCornerShape(14.dp), shadowElevation = 6.dp, color = Color.White) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            placeholder = { Text("Buscar paradero, calle o lugar", fontSize = 14.sp, maxLines = 1) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f)
                        )
                        if (query.isNotEmpty()) {
                            TextButton(onClick = { query = ""; results = emptyList(); searchMsg = null }) {
                                Text("✕", color = Color.Gray)
                            }
                        }
                        TextButton(onClick = { doSearch() }) { Text("🔍", fontSize = 20.sp) }
                    }
                }
                if (searching) {
                    Spacer(Modifier.height(6.dp))
                    Surface(shape = RoundedCornerShape(14.dp), shadowElevation = 6.dp, color = Color.White) {
                        Text("Buscando…", Modifier.padding(14.dp), color = Color.Gray, fontSize = 13.sp)
                    }
                } else if (results.isNotEmpty() || searchMsg != null) {
                    Spacer(Modifier.height(6.dp))
                    Surface(shape = RoundedCornerShape(14.dp), shadowElevation = 6.dp, color = Color.White) {
                        if (results.isEmpty()) {
                            Text(searchMsg ?: "", Modifier.padding(14.dp), color = Color.Gray, fontSize = 13.sp)
                        } else {
                            LazyColumn(Modifier.heightIn(max = 260.dp)) {
                                items(results) { h ->
                                    Column(
                                        Modifier.fillMaxWidth()
                                            .clickable { pickPlace(h) }
                                            .padding(horizontal = 14.dp, vertical = 8.dp)
                                    ) {
                                        Text(
                                            (if (h.stop) "🚏 " else "📍 ") + h.name,
                                            color = Blue900, fontWeight = FontWeight.Medium, fontSize = 14.sp,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            h.detail, color = Color.Gray, fontSize = 11.sp,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    HorizontalDivider()
                                }
                            }
                        }
                    }
                }
            }

            SmallFloatingActionButton(
                onClick = {
                    if (hasLoc) goToMyLocation() else locPerm.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                },
                containerColor = Color.White,
                contentColor = Blue500,
                modifier = Modifier.align(Alignment.BottomStart).padding(12.dp)
            ) { Text("◎", fontSize = 22.sp) }
        }

        // Panel inferior redondeado
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(Color.White)
                .navigationBarsPadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val activeText = "$activeCount alarma${if (activeCount == 1) "" else "s"} activa${if (activeCount == 1) "" else "s"}"
            Text(
                when {
                    target != null ->
                        "Lugar: ${targetName ?: "punto del mapa"}" + if (activeCount > 0) "  ·  $activeText" else ""
                    activeCount > 0 -> "$activeText ✓ (suenan al llegar)"
                    else -> "Busca o toca el mapa para elegir un lugar"
                },
                color = Blue900, fontWeight = FontWeight.SemiBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Radio: ${radius.toInt()} m", color = Blue700, fontWeight = FontWeight.Medium,
                    maxLines = 1, modifier = Modifier.width(120.dp))
                Slider(
                    value = radius,
                    onValueChange = { radius = it.toInt().coerceIn(30, 300).toFloat() },
                    valueRange = 30f..300f,
                    colors = SliderDefaults.colors(
                        thumbColor = Blue500, activeTrackColor = Blue500,
                        inactiveTrackColor = Blue50
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(
                    onClick = { showFavs = true },
                    modifier = Modifier.weight(1f)
                ) { Text("★ Guardados", maxLines = 1) }
                FilledTonalButton(
                    onClick = { pickAudio.launch(arrayOf("audio/*")) },
                    modifier = Modifier.weight(1f)
                ) { Text(if (audio == null) "Elegir sonido" else "Cambiar sonido", maxLines = 1) }
            }
            Text(
                if (audio == null) "Sin sonido elegido: sonará la alarma del teléfono"
                else "Sonido para nuevas alarmas: ${audioName ?: "archivo de audio"}",
                fontSize = 12.sp, color = Color.Gray,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )

            if (AlarmService.ringing) {
                Button(
                    onClick = { ctx.stopService(Intent(ctx, AlarmService::class.java)) },
                    colors = ButtonDefaults.buttonColors(containerColor = Red),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("Detener alarma", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = target != null,
                    onClick = {
                        val need = mutableListOf<String>()
                        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION))
                            need += Manifest.permission.ACCESS_FINE_LOCATION
                        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS))
                            need += Manifest.permission.POST_NOTIFICATIONS
                        if (need.isEmpty()) proceed() else fgPerms.launch(need.toTypedArray())
                    },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1.4f).height(52.dp)
                ) { Text("＋ Agregar alarma", fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
                OutlinedButton(
                    onClick = { showAlarms = true },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f).height(52.dp)
                ) { Text("⏰ Alarmas ($activeCount/${alarms.size})", fontSize = 14.sp, maxLines = 1) }
            }
        }
    }

    // Lista de alarmas: cada una se activa, pausa o borra por separado
    if (showAlarms) {
        AlertDialog(
            onDismissRequest = { showAlarms = false },
            confirmButton = { TextButton(onClick = { showAlarms = false }) { Text("Cerrar") } },
            dismissButton = {
                if (activeCount > 0) TextButton(onClick = {
                    alarms.filter { it.active }.forEach { GeofenceHelper.remove(ctx, it.id) }
                    AlarmStore.deactivateAll(ctx)
                    TrackingService.stop(ctx)
                }) { Text("Pausar todas", color = Red) }
            },
            title = { Text("Mis alarmas") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (alarms.isEmpty()) {
                        Text(
                            "Aún no tienes alarmas. Elige un lugar en el mapa y toca \"Agregar alarma\". Puedes tener varias a la vez.",
                            fontSize = 13.sp, color = Color.Gray
                        )
                    }
                    LazyColumn(Modifier.heightIn(max = 340.dp)) {
                        items(alarms, key = { it.id }) { a ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(
                                    Modifier.weight(1f).clickable {
                                        val p = GeoPoint(a.lat, a.lon)
                                        centerOn(p)
                                        showAlarms = false
                                    }
                                ) {
                                    Text(
                                        a.name, color = Blue900, fontWeight = FontWeight.Medium,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        "Radio ${a.radius.toInt()} m · " + if (a.active) "activa" else "pausada",
                                        fontSize = 12.sp, color = if (a.active) Blue700 else Color.Gray
                                    )
                                }
                                Switch(checked = a.active, onCheckedChange = { toggleAlarm(a, it) })
                                TextButton(onClick = { deleteAlarm(a) }) { Text("✕", color = Red) }
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }
        )
    }

    // Lugares y paraderos frecuentes
    if (showFavs) {
        AlertDialog(
            onDismissRequest = { showFavs = false },
            confirmButton = { TextButton(onClick = { showFavs = false }) { Text("Cerrar") } },
            title = { Text("Lugares guardados") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (favs.isEmpty()) {
                        Text(
                            "Aún no tienes lugares guardados. Toca un paradero o un punto del mapa y guárdalo aquí.",
                            fontSize = 13.sp, color = Color.Gray
                        )
                    }
                    LazyColumn(Modifier.heightIn(max = 220.dp)) {
                        items(favs) { f ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable {
                                        val p = GeoPoint(f.lat, f.lon)
                                        target = p; targetName = f.name
                                        centerOn(p)
                                        showFavs = false
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "★ ${f.name}", Modifier.weight(1f), color = Blue900,
                                    fontWeight = FontWeight.Medium, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                TextButton(onClick = {
                                    AlarmStore.removeFav(ctx, f.name)
                                    favs.remove(f)
                                }) { Text("Borrar", color = Red) }
                            }
                        }
                    }
                    HorizontalDivider()
                    if (target == null) {
                        Text(
                            "Para guardar un lugar, primero búscalo, tócalo en el mapa o toca un paradero.",
                            fontSize = 12.sp, color = Color.Gray
                        )
                    }
                    OutlinedTextField(
                        value = favName,
                        onValueChange = { favName = it },
                        label = { Text("Nombre del lugar") },
                        singleLine = true,
                        enabled = target != null,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        enabled = target != null && favName.isNotBlank(),
                        onClick = {
                            val f = Fav(favName.trim(), target!!.latitude, target!!.longitude)
                            AlarmStore.addFav(ctx, f)
                            favs.removeAll { it.name == f.name }
                            favs.add(f)
                            favName = ""
                            Toast.makeText(ctx, "Lugar guardado", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Guardar lugar elegido") }
                }
            }
        )
    }
}

@Composable
fun OsmMap(
    modifier: Modifier,
    target: GeoPoint?,
    radius: Float,
    alarms: List<Alarm>,
    centerReq: Pair<GeoPoint, Int>?,
    hasLocation: Boolean,
    onMapView: (MapView) -> Unit,
    onTap: (GeoPoint, String?) -> Unit
) {
    val ctx = LocalContext.current
    val mapView = remember {
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)   // calles con nombre
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.SHOW_AND_FADEOUT)
            controller.setZoom(16.0)
            controller.setCenter(GeoPoint(4.65, -74.08))
        }
    }
    val myLoc = remember { MyLocationNewOverlay(GpsMyLocationProvider(ctx), mapView) }
    val currentOnTap by rememberUpdatedState(onTap)
    var stops by remember { mutableStateOf(listOf<Stop>()) }
    var tick by remember { mutableStateOf(0) }

    LaunchedEffect(mapView) { onMapView(mapView) }

    DisposableEffect(mapView) {
        mapView.onResume()
        val l = object : MapListener {
            override fun onScroll(event: ScrollEvent?): Boolean { tick++; return false }
            override fun onZoom(event: ZoomEvent?): Boolean { tick++; return false }
        }
        mapView.addMapListener(l)
        onDispose {
            mapView.removeMapListener(l)
            mapView.onPause()
            mapView.onDetach()
        }
    }

    // Punto azul con tu ubicación
    DisposableEffect(hasLocation) {
        if (hasLocation) {
            myLoc.enableMyLocation()
            if (!mapView.overlays.contains(myLoc)) mapView.overlays.add(myLoc)
        }
        onDispose { myLoc.disableMyLocation() }
    }

    LaunchedEffect(centerReq) {
        centerReq?.let {
            mapView.controller.setZoom(17.0)
            mapView.controller.animateTo(it.first)
        }
    }

    // Paraderos de la zona visible (se cargan al acercar el mapa)
    LaunchedEffect(tick) {
        delay(700)
        if (mapView.zoomLevelDouble < 15.0) { stops = emptyList(); return@LaunchedEffect }
        val bb = mapView.boundingBox
        stops = withContext(Dispatchers.IO) { fetchStops(bb) }
    }

    AndroidView(
        modifier = modifier,
        factory = {
            mapView.overlays.add(0, MapEventsOverlay(object : MapEventsReceiver {
                override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                    currentOnTap(p, null); return true
                }
                override fun longPressHelper(p: GeoPoint): Boolean = false
            }))
            mapView
        },
        update = { mv ->
            mv.overlays.filter { it is Marker || it is Polygon }.forEach { mv.overlays.remove(it) }

            val icon = stopIcon(mv.context)
            stops.forEach { s ->
                mv.overlays.add(Marker(mv).apply {
                    position = GeoPoint(s.lat, s.lon)
                    title = s.name
                    setIcon(icon)
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                    // Tocar un paradero lo elige como destino
                    setOnMarkerClickListener { m, _ ->
                        currentOnTap(m.position, s.name)
                        m.showInfoWindow()
                        true
                    }
                })
            }

            // Alarmas ya creadas: azul si están activas, gris si están pausadas
            alarms.forEach { a ->
                val c = GeoPoint(a.lat, a.lon)
                mv.overlays.add(Polygon(mv).apply {
                    points = Polygon.pointsAsCircle(c, a.radius.toDouble())
                    fillPaint.color = if (a.active) 0x331E88E5 else 0x22757575
                    outlinePaint.color = if (a.active) 0xFF1E88E5.toInt() else 0xFF9E9E9E.toInt()
                    outlinePaint.strokeWidth = 4f
                })
                mv.overlays.add(Marker(mv).apply {
                    position = c
                    title = a.name + if (a.active) "" else " (pausada)"
                    setIcon(alarmIcon(mv.context, a.active))
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                })
            }

            // Lugar que estás eligiendo ahora (verde)
            target?.let { t ->
                mv.overlays.add(Polygon(mv).apply {
                    points = Polygon.pointsAsCircle(t, radius.toDouble())
                    fillPaint.color = 0x3343A047
                    outlinePaint.color = 0xFF43A047.toInt()
                    outlinePaint.strokeWidth = 4f
                })
                mv.overlays.add(Marker(mv).apply {
                    position = t
                    title = "Nuevo lugar"
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                })
            }
            mv.invalidate()
        }
    )
}

private fun stopIcon(ctx: Context): Drawable {
    val size = (ctx.resources.displayMetrics.density * 18).toInt()
    return GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(0xFFFF9800.toInt())
        setStroke(3, 0xFFFFFFFF.toInt())
        setSize(size, size)
    }
}

private fun alarmIcon(ctx: Context, active: Boolean): Drawable {
    val size = (ctx.resources.displayMetrics.density * 20).toInt()
    return GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(if (active) 0xFF1E88E5.toInt() else 0xFF9E9E9E.toInt())
        setStroke(4, 0xFFFFFFFF.toInt())
        setSize(size, size)
    }
}

private fun audioDisplayName(ctx: Context, uri: Uri): String? = try {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    }
} catch (e: Exception) { null }

private fun httpGet(url: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 10000
    c.readTimeout = 15000
    c.setRequestProperty("User-Agent", APP_USER_AGENT)
    return c.inputStream.bufferedReader().use { it.readText() }
}

// Paraderos de bus desde OpenStreetMap (Overpass API, gratis y sin clave)
private fun fetchStops(bb: BoundingBox): List<Stop> = try {
    val q = "[out:json][timeout:15];" +
        "node[\"highway\"=\"bus_stop\"](${bb.latSouth},${bb.lonWest},${bb.latNorth},${bb.lonEast});" +
        "out 150;"
    val body = httpGet("https://overpass-api.de/api/interpreter?data=" + URLEncoder.encode(q, "UTF-8"))
    val arr = JSONObject(body).getJSONArray("elements")
    (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        val name = o.optJSONObject("tags")?.optString("name", "")?.takeIf { it.isNotBlank() } ?: "Paradero"
        Stop(o.getDouble("lat"), o.getDouble("lon"), name)
    }
} catch (e: Exception) {
    emptyList()
}

// ---------- Buscador ----------

// Busca paraderos por nombre (cerca de donde está el mapa) y lugares/calles en todo OpenStreetMap
private fun searchPlaces(q: String, box: BoundingBox?): SearchResult {
    val hits = mutableListOf<PlaceHit>()
    var okCount = 0
    if (box != null) {
        try { hits += searchStops(q, box); okCount++ } catch (e: Exception) { }
    }
    try { hits += searchNominatim(q, box); okCount++ } catch (e: Exception) { }
    val unique = hits.distinctBy { Pair((it.lat * 10000).toInt(), (it.lon * 10000).toInt()) }
    return SearchResult(unique, okCount == 0)
}

private fun searchStops(q: String, box: BoundingBox): List<PlaceHit> {
    val s = q.filter { it.isLetterOrDigit() || it == ' ' }.trim()   // quita símbolos para la búsqueda
    if (s.length < 2) return emptyList()
    val lat = (box.latNorth + box.latSouth) / 2
    val lon = (box.lonEast + box.lonWest) / 2
    val d = 0.08   // unos 9 km alrededor del centro del mapa
    val ql = "[out:json][timeout:15];" +
        "node[\"highway\"=\"bus_stop\"][\"name\"~\"$s\",i](${lat - d},${lon - d},${lat + d},${lon + d});" +
        "out 25;"
    val body = httpGet("https://overpass-api.de/api/interpreter?data=" + URLEncoder.encode(ql, "UTF-8"))
    val arr = JSONObject(body).getJSONArray("elements")
    val list = (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        val name = o.optJSONObject("tags")?.optString("name", "")?.takeIf { it.isNotBlank() } ?: "Paradero"
        PlaceHit(name, "Paradero de bus", o.getDouble("lat"), o.getDouble("lon"), true)
    }
    // Los más cercanos al centro del mapa primero
    return list.sortedBy { (it.lat - lat) * (it.lat - lat) + (it.lon - lon) * (it.lon - lon) }.take(6)
}

private fun searchNominatim(q: String, box: BoundingBox?): List<PlaceHit> {
    val vb = if (box != null) {
        val lat = (box.latNorth + box.latSouth) / 2
        val lon = (box.lonEast + box.lonWest) / 2
        "&viewbox=${lon - 0.25},${lat + 0.25},${lon + 0.25},${lat - 0.25}"   // prefiere resultados cercanos
    } else ""
    val url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=8&accept-language=es" +
        vb + "&q=" + URLEncoder.encode(q, "UTF-8")
    val arr = JSONArray(httpGet(url))
    return (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        val display = o.optString("display_name", "")
        val name = o.optString("name", "").ifBlank { display.substringBefore(",") }.ifBlank { "Lugar" }
        PlaceHit(name, display, o.getString("lat").toDouble(), o.getString("lon").toDouble(), false)
    }
}

// Nombre de la calle/lugar de un punto tocado en el mapa
private fun reverseName(lat: Double, lon: Double): String? = try {
    val o = JSONObject(
        httpGet("https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&accept-language=es&lat=$lat&lon=$lon")
    )
    val road = o.optJSONObject("address")?.optString("road", "")?.takeIf { it.isNotBlank() }
    o.optString("name", "").takeIf { it.isNotBlank() }
        ?: road
        ?: o.optString("display_name", "").substringBefore(",").takeIf { it.isNotBlank() }
} catch (e: Exception) { null }

@SuppressLint("BatteryLife")
private fun addAlarm(ctx: Context, a: Alarm) {
    AlarmStore.add(ctx, a)

    // Principal: GPS en un servicio en primer plano (funciona con otras apps y pantalla apagada).
    // Si ya estaba corriendo, solo recarga la lista con la alarma nueva.
    TrackingService.start(ctx)
    // Respaldo: geovalla de Google
    GeofenceHelper.register(ctx, a)

    // Pide una sola vez que Android no "duerma" la app para ahorrar batería
    try {
        val pm = ctx.getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(ctx.packageName) && AlarmStore.firstTime(ctx, "battery")) {
            ctx.startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
            )
        }
    } catch (e: Exception) { }
    Toast.makeText(ctx, "Alarma agregada: ${a.name}", Toast.LENGTH_SHORT).show()
}
