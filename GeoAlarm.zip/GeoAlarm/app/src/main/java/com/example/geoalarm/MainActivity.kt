package com.example.geoalarm

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

// Identificación de la app ante los servidores de OpenStreetMap (obligatorio por su política de uso)
const val APP_USER_AGENT =
    "GeoAlarma/1.0 (Android; alarma por ubicacion; uso personal; https://github.com/Lcdorichardquintero621/Geo-Alarmas)"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().apply {
            userAgentValue = APP_USER_AGENT
            tileDownloadThreads = 2
            tileFileSystemThreads = 2
            osmdroidBasePath = File(cacheDir, "osmdroid")
            osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
        }
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        setContent { GeoTheme { Screen() } }
    }
}

data class Stop(val lat: Double, val lon: Double, val name: String)

@SuppressLint("MissingPermission")
@Composable
fun Screen() {
    val ctx = LocalContext.current
    var target by remember { mutableStateOf<GeoPoint?>(null) }
    var audio by remember { mutableStateOf<Uri?>(null) }
    var showStops by remember { mutableStateOf(true) }
    var radius by remember { mutableStateOf(50f) }
    var center by remember { mutableStateOf<GeoPoint?>(null) }
    val diag = remember { diagnostics(ctx) }

    fun goToMyLocation() {
        LocationServices.getFusedLocationProviderClient(ctx).lastLocation
            .addOnSuccessListener { l -> if (l != null) center = GeoPoint(l.latitude, l.longitude) }
    }

    val locPerm = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok -> if (ok) goToMyLocation() }

    LaunchedEffect(Unit) {
        val granted = ContextCompat.checkSelfPermission(
            ctx, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) goToMyLocation() else locPerm.launch(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    val pickAudio = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            audio = uri
        }
    }

    val bgPerm = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        if (ok) activate(ctx, target!!, audio!!, radius)
        else Toast.makeText(ctx, "Debes permitir la ubicación 'Siempre'", Toast.LENGTH_LONG).show()
    }

    val fgPerms = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { r ->
        if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            if (Build.VERSION.SDK_INT >= 29) bgPerm.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            else activate(ctx, target!!, audio!!, radius)
        }
    }

    Column(Modifier.fillMaxSize().background(Blue50)) {
        // Cabecera con degradado azul, icono + nombre
        Row(
            Modifier.fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(Blue900, Blue500)))
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(R.drawable.ic_logo),
                contentDescription = "Icono Geo-Alarma",
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(11.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Geo-Alarma", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Te aviso cuando llegues", color = Blue50, fontSize = 13.sp)
            }
        }

        Box(Modifier.weight(1f)) {
            OsmMap(
                modifier = Modifier.fillMaxSize(),
                target = target,
                radius = radius,
                showStops = showStops,
                center = center,
                onTap = { target = it }
            )
        }

        // Panel inferior redondeado
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(Color.White)
                .navigationBarsPadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                if (target == null) "Toca el mapa para elegir el lugar"
                else "Lugar elegido ✓",
                color = Blue900, fontWeight = FontWeight.SemiBold
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Radio: ${radius.toInt()} m", color = Blue700, fontWeight = FontWeight.Medium,
                    maxLines = 1, modifier = Modifier.width(120.dp))
                Slider(
                    value = radius,
                    onValueChange = { radius = it.toInt().coerceIn(1, 100).toFloat() },
                    valueRange = 1f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = Blue500, activeTrackColor = Blue500,
                        inactiveTrackColor = Blue50
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(
                    onClick = { showStops = !showStops },
                    modifier = Modifier.weight(1f)
                ) { Text(if (showStops) "Paraderos: sí" else "Paraderos: no", maxLines = 1) }
                FilledTonalButton(
                    onClick = { pickAudio.launch(arrayOf("audio/*")) },
                    modifier = Modifier.weight(1f)
                ) { Text(if (audio == null) "Elegir sonido" else "Sonido ✓", maxLines = 1) }
            }
            Text(
                if (showStops) "Acerca el mapa para ver los paraderos" else "",
                fontSize = 11.sp, color = Color.Gray
            )
            Text(diag, fontSize = 11.sp, color = Color.Gray)
            Button(
                enabled = target != null && audio != null,
                onClick = {
                    val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
                    if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
                    fgPerms.launch(perms.toTypedArray())
                },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Activar alarma", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun OsmMap(
    modifier: Modifier,
    target: GeoPoint?,
    radius: Float,
    showStops: Boolean,
    center: GeoPoint?,
    onTap: (GeoPoint) -> Unit
) {
    val ctx = LocalContext.current
    val mapView = remember {
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)   // calles con nombre y paraderos
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.SHOW_AND_FADEOUT)
            controller.setZoom(16.0)
            controller.setCenter(GeoPoint(4.65, -74.08))
        }
    }
    val currentOnTap by rememberUpdatedState(onTap)
    var stops by remember { mutableStateOf(listOf<Stop>()) }
    var tick by remember { mutableStateOf(0) }

    DisposableEffect(mapView) {
        mapView.onResume()
        val l = object : MapListener {
            override fun onScroll(event: ScrollEvent?): Boolean { tick++; return false }
            override fun onZoom(event: ZoomEvent?): Boolean { tick++; return false }
        }
        mapView.addMapListener(l)
        onDispose {
            mapView.removeMapListener(l)
            mapView.onPause()
            mapView.onDetach()
        }
    }

    LaunchedEffect(center) {
        center?.let {
            mapView.controller.setZoom(17.0)
            mapView.controller.animateTo(it)
        }
    }

    // Carga los paraderos de la zona visible (con una pequeña espera al mover el mapa)
    LaunchedEffect(showStops, tick) {
        if (!showStops) { stops = emptyList(); return@LaunchedEffect }
        delay(700)
        if (mapView.zoomLevelDouble < 15.0) { stops = emptyList(); return@LaunchedEffect }
        val bb = mapView.boundingBox
        stops = withContext(Dispatchers.IO) { fetchStops(bb) }
    }

    AndroidView(
        modifier = modifier,
        factory = {
            mapView.overlays.add(0, MapEventsOverlay(object : MapEventsReceiver {
                override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                    currentOnTap(p); return true
                }
                override fun longPressHelper(p: GeoPoint): Boolean = false
            }))
            mapView
        },
        update = { mv ->
            mv.overlays.filter { it is Marker || it is Polygon }.forEach { mv.overlays.remove(it) }

            if (showStops) {
                val icon = stopIcon(mv.context)
                stops.forEach { s ->
                    mv.overlays.add(Marker(mv).apply {
                        position = GeoPoint(s.lat, s.lon)
                        title = s.name
                        setIcon(icon)
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                    })
                }
            }
            target?.let { t ->
                mv.overlays.add(Polygon(mv).apply {
                    points = Polygon.pointsAsCircle(t, radius.toDouble())
                    fillPaint.color = 0x331E88E5
                    outlinePaint.color = 0xFF1E88E5.toInt()
                    outlinePaint.strokeWidth = 4f
                })
                mv.overlays.add(Marker(mv).apply {
                    position = t
                    title = "Destino"
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                })
            }
            mv.invalidate()
        }
    )
}

private fun stopIcon(ctx: Context): Drawable {
    val size = (ctx.resources.displayMetrics.density * 16).toInt()
    return GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(0xFFFF9800.toInt())
        setStroke(3, 0xFFFFFFFF.toInt())
        setSize(size, size)
    }
}

// Paraderos de bus desde OpenStreetMap (Overpass API, gratis y sin clave)
private fun fetchStops(bb: BoundingBox): List<Stop> = try {
    val q = "[out:json][timeout:15];" +
        "node[\"highway\"=\"bus_stop\"](${bb.latSouth},${bb.lonWest},${bb.latNorth},${bb.lonEast});" +
        "out 150;"
    val url = URL("https://overpass-api.de/api/interpreter?data=" + URLEncoder.encode(q, "UTF-8"))
    val c = url.openConnection() as HttpURLConnection
    c.connectTimeout = 10000
    c.readTimeout = 15000
    c.setRequestProperty("User-Agent", APP_USER_AGENT)
    val body = c.inputStream.bufferedReader().use { it.readText() }
    val arr = JSONObject(body).getJSONArray("elements")
    (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        val name = o.optJSONObject("tags")?.optString("name", "")?.takeIf { it.isNotBlank() } ?: "Paradero"
        Stop(o.getDouble("lat"), o.getDouble("lon"), name)
    }
} catch (e: Exception) {
    emptyList()
}

@SuppressLint("MissingPermission")
private fun activate(ctx: Context, p: GeoPoint, audio: Uri, radius: Float) {
    AlarmStore.save(ctx, p.latitude, p.longitude, audio.toString())

    val geofence = Geofence.Builder()
        .setRequestId("destino")
        .setCircularRegion(p.latitude, p.longitude, radius)
        .setExpirationDuration(Geofence.NEVER_EXPIRE)
        .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
        .build()
    val request = GeofencingRequest.Builder()
        .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
        .addGeofence(geofence).build()
    val pi = PendingIntent.getBroadcast(
        ctx, 0, Intent(ctx, GeofenceReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
    )
    val client = LocationServices.getGeofencingClient(ctx)
    client.removeGeofences(pi)
    client.addGeofences(request, pi)
        .addOnSuccessListener { Toast.makeText(ctx, "Alarma activada", Toast.LENGTH_SHORT).show() }
        .addOnFailureListener { Toast.makeText(ctx, "Error: ${it.message}", Toast.LENGTH_LONG).show() }
}

private fun diagnostics(ctx: Context): String {
    val code = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(ctx)
    val gms = if (code == ConnectionResult.SUCCESS) "OK" else "problema (código $code)"
    return "Mapa: OpenStreetMap  |  Google Play Services: $gms"
}
