package com.example.geoalarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.provider.Settings
import androidx.core.content.ContextCompat

// Punto único para disparar la alarma (lo usan el GPS y la geovalla). Solo suena una vez.
object AlarmTrigger {
    fun fire(ctx: Context) {
        val c = ctx.applicationContext
        if (!AlarmStore.consumeActive(c)) return   // ya sonó o fue desactivada

        GeofenceHelper.remove(c)
        try {
            // Se lanza ANTES de detener el seguimiento, para que Android lo permita en segundo plano
            ContextCompat.startForegroundService(c, Intent(c, AlarmService::class.java))
        } catch (e: Exception) {
            fallbackNotification(c)
        }
        TrackingService.stop(c)
    }

    // Respaldo: si Android no deja iniciar el servicio, al menos una notificación con sonido
    private fun fallbackNotification(c: Context) {
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel("alarm_fallback", "Alarma (respaldo)", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(
                Settings.System.DEFAULT_ALARM_ALERT_URI,
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
            )
            ch.enableVibration(true)
            nm.createNotificationChannel(ch)
            val open = PendingIntent.getActivity(
                c, 2, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(c, "alarm_fallback")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("¡Llegaste a tu destino!")
                .setContentText("Toca para abrir Geo-Alarma")
                .setCategory(Notification.CATEGORY_ALARM)
                .setFullScreenIntent(open, true)
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify(3, n)
        } catch (e: Exception) { }
    }
}
