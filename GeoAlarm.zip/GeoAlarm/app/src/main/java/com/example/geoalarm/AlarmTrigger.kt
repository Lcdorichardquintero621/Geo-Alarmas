package com.example.geoalarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.provider.Settings
import androidx.core.content.ContextCompat

// Punto único para disparar UNA alarma (lo usan el GPS y la geovalla). Cada una suena una sola vez.
object AlarmTrigger {
    // Devuelve true si esta alarma sonó ahora (false si ya había sonado o estaba desactivada)
    fun fire(ctx: Context, id: String): Boolean {
        val c = ctx.applicationContext
        val a = AlarmStore.consume(c, id) ?: return false

        GeofenceHelper.remove(c, a.id)
        try {
            ContextCompat.startForegroundService(
                c,
                Intent(c, AlarmService::class.java)
                    .putExtra(AlarmService.EXTRA_NAME, a.name)
                    .putExtra(AlarmService.EXTRA_AUDIO, a.audio)
            )
        } catch (e: Exception) {
            fallbackNotification(c, a)
        }
        return true
    }

    // Respaldo: si Android no deja iniciar el servicio, al menos una notificación con sonido
    private fun fallbackNotification(c: Context, a: Alarm) {
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel("alarm_fallback", "Alarma (respaldo)", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(
                Settings.System.DEFAULT_ALARM_ALERT_URI,
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
            )
            ch.enableVibration(true)
            nm.createNotificationChannel(ch)
            val open = PendingIntent.getActivity(
                c, 2, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(c, "alarm_fallback")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("¡Llegaste a ${a.name}!")
                .setContentText("Toca para abrir Geo-Alarma")
                .setCategory(Notification.CATEGORY_ALARM)
                .setFullScreenIntent(open, true)
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify(a.id.hashCode(), n)
        } catch (e: Exception) { }
    }
}
