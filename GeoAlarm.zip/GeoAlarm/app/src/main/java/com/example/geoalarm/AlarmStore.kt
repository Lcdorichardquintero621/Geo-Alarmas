package com.example.geoalarm

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class Fav(val name: String, val lat: Double, val lon: Double)

// Cada alarma es independiente: tiene su lugar, radio, sonido y su propio estado (activa/pausada)
data class Alarm(
    val id: String,
    val name: String,
    val lat: Double,
    val lon: Double,
    val radius: Float,
    val audio: String?,
    val active: Boolean
)

object AlarmStore {
    // Lista que lee la interfaz (se actualiza sola en cada cambio)
    var alarms by mutableStateOf(listOf<Alarm>())
        private set

    private fun p(c: Context) = c.getSharedPreferences("alarm", Context.MODE_PRIVATE)

    fun load(c: Context) { alarms = read(c) }

    @Synchronized
    private fun read(c: Context): List<Alarm> {
        val sp = p(c)
        if (!sp.contains("alarms")) {
            // Migra la alarma única de versiones anteriores
            val lat = sp.getString("lat", null)?.toDoubleOrNull()
            val lng = sp.getString("lng", null)?.toDoubleOrNull()
            val list = if (lat != null && lng != null)
                listOf(
                    Alarm(
                        "antigua", "Destino", lat, lng, sp.getFloat("radius", 50f),
                        sp.getString("audio", null), sp.getBoolean("active", false)
                    )
                )
            else emptyList()
            write(c, list)
            return list
        }
        return try {
            val arr = JSONArray(sp.getString("alarms", "[]"))
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Alarm(
                    o.getString("id"), o.getString("name"), o.getDouble("lat"), o.getDouble("lon"),
                    o.getDouble("radius").toFloat(),
                    if (o.has("audio") && !o.isNull("audio")) o.getString("audio") else null,
                    o.getBoolean("active")
                )
            }
        } catch (e: Exception) { emptyList() }
    }

    @Synchronized
    private fun write(c: Context, list: List<Alarm>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name).put("lat", it.lat)
                    .put("lon", it.lon).put("radius", it.radius.toDouble())
                    .put("audio", it.audio ?: JSONObject.NULL).put("active", it.active)
            )
        }
        p(c).edit().putString("alarms", arr.toString()).apply()
        alarms = list
    }

    fun activeAlarms(c: Context): List<Alarm> = read(c).filter { it.active }

    @Synchronized fun add(c: Context, a: Alarm) = write(c, read(c) + a)

    @Synchronized fun setActive(c: Context, id: String, v: Boolean) =
        write(c, read(c).map { if (it.id == id) it.copy(active = v) else it })

    @Synchronized fun remove(c: Context, id: String) = write(c, read(c).filter { it.id != id })

    @Synchronized fun deactivateAll(c: Context) = write(c, read(c).map { it.copy(active = false) })

    // Marca UNA alarma como disparada (queda pausada). Devuelve null si ya sonó o está desactivada,
    // así no suena dos veces aunque la pidan el GPS y la geovalla a la vez.
    @Synchronized
    fun consume(c: Context, id: String): Alarm? {
        val list = read(c)
        val a = list.firstOrNull { it.id == id && it.active } ?: return null
        write(c, list.map { if (it.id == id) it.copy(active = false) else it })
        return a
    }

    // true solo la primera vez (para no repetir avisos de permisos)
    fun firstTime(c: Context, key: String): Boolean {
        val k = "asked_$key"
        if (p(c).getBoolean(k, false)) return false
        p(c).edit().putBoolean(k, true).apply()
        return true
    }

    // El último sonido elegido se queda guardado para las próximas alarmas
    fun saveAudio(c: Context, uri: String) = p(c).edit().putString("audio", uri).apply()
    fun audio(c: Context): String? = p(c).getString("audio", null)

    // Lugares / paraderos frecuentes
    fun favs(c: Context): List<Fav> = try {
        val arr = JSONArray(p(c).getString("favs", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Fav(o.getString("name"), o.getDouble("lat"), o.getDouble("lon"))
        }
    } catch (e: Exception) { emptyList() }

    private fun writeFavs(c: Context, list: List<Fav>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("name", it.name).put("lat", it.lat).put("lon", it.lon))
        }
        p(c).edit().putString("favs", arr.toString()).apply()
    }

    fun addFav(c: Context, f: Fav) = writeFavs(c, favs(c).filter { it.name != f.name } + f)
    fun removeFav(c: Context, name: String) = writeFavs(c, favs(c).filter { it.name != name })
}
