package com.example.geoalarm

import android.content.Context

object AlarmStore {
    private fun p(c: Context) = c.getSharedPreferences("alarm", Context.MODE_PRIVATE)
    fun save(c: Context, lat: Double, lng: Double, audio: String) =
        p(c).edit().putString("lat", lat.toString()).putString("lng", lng.toString())
            .putString("audio", audio).apply()
    fun audio(c: Context): String? = p(c).getString("audio", null)
}
