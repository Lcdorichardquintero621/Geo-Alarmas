package com.example.geoalarm

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class Fav(val name: String, val lat: Double, val lon: Double)

object AlarmStore {
    // true mientras la geovalla está activa (lo lee la interfaz)
    var active by mutableStateOf(false)
        private set

    private fun p(c: Context) = c.getSharedPreferences("alarm", Context.MODE_PRIVATE)

    fun load(c: Context) { active = p(c).getBoolean("active", false) }

    fun setActive(c: Context, v: Boolean) {
        p(c).edit().putBoolean("active", v).apply()
        active = v
    }

    fun savePlace(c: Context, lat: Double, lng: Double, radius: Float) =
        p(c).edit().putString("lat", lat.toString()).putString("lng", lng.toString())
            .putFloat("radius", radius).apply()

    fun place(c: Context): Triple<Double, Double, Float>? {
        val lat = p(c).getString("lat", null)?.toDoubleOrNull() ?: return null
        val lng = p(c).getString("lng", null)?.toDoubleOrNull() ?: return null
        return Triple(lat, lng, p(c).getFloat("radius", 50f))
    }

    // El sonido elegido se queda guardado hasta que se reemplace
    fun saveAudio(c: Context, uri: String) = p(c).edit().putString("audio", uri).apply()
    fun audio(c: Context): String? = p(c).getString("audio", null)

    // Lugares / paraderos frecuentes
    fun favs(c: Context): List<Fav> = try {
        val arr = JSONArray(p(c).getString("favs", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Fav(o.getString("name"), o.getDouble("lat"), o.getDouble("lon"))
        }
    } catch (e: Exception) { emptyList() }

    private fun writeFavs(c: Context, list: List<Fav>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("name", it.name).put("lat", it.lat).put("lon", it.lon))
        }
        p(c).edit().putString("favs", arr.toString()).apply()
    }

    fun addFav(c: Context, f: Fav) = writeFavs(c, favs(c).filter { it.name != f.name } + f)
    fun removeFav(c: Context, name: String) = writeFavs(c, favs(c).filter { it.name != name })
}
