package com.example.geoalarm

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Blue900 = Color(0xFF0D47A1)
val Blue700 = Color(0xFF1565C0)
val Blue500 = Color(0xFF1E88E5)
val Blue300 = Color(0xFF64B5F6)
val Blue50 = Color(0xFFE3F2FD)

@Composable
fun GeoTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = lightColorScheme(
        primary = Blue500,
        onPrimary = Color.White,
        primaryContainer = Blue50,
        onPrimaryContainer = Blue900,
        secondaryContainer = Blue50,
        onSecondaryContainer = Blue700,
        surface = Color.White,
        background = Blue50
    ),
    content = content
)
