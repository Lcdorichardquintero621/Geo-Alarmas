package com.example.geoalarm

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

// Servicio en primer plano (tipo "location"): sigue midiendo la distancia con GPS aunque
// estés en otra app, navegando o con la pantalla apagada.
class TrackingService : Service() {
    companion object {
        const val ACTION_STOP = "STOP_TRACKING"
        private const val CHANNEL = "tracking"
        private const val NOTIF_ID = 2
        private const val MIN_RADIUS = 30f          // por debajo de esto el GPS no es fiable
        private const val MAX_ACCURACY = 100f       // se ignoran lecturas peores que 100 m

        fun start(ctx: Context) =
            ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java))

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, TrackingService::class.java)) }
    }

    private lateinit var client: FusedLocationProviderClient
    private var wakeLock: PowerManager.WakeLock? = null
    private var near: Boolean? = null
    private var lat = 0.0
    private var lon = 0.0
    private var radius = MIN_RADIUS

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            var last = Float.MAX_VALUE
            for (loc in result.locations) {
                val d = FloatArray(1)
                Location.distanceBetween(loc.latitude, loc.longitude, lat, lon, d)
                last = d[0]
                if (loc.accuracy <= MAX_ACCURACY && d[0] <= radius) {
                    AlarmTrigger.fire(this@TrackingService)
                    return
                }
            }
            // Lejos: GPS más espaciado (ahorra batería). Cerca: GPS cada 2 s
            val wantNear = if (near == true) last < 3000f else last < 2000f
            applyMode(wantNear)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            AlarmStore.setActive(this, false)
            GeofenceHelper.remove(this)
            stopSelf()
            return START_NOT_STICKY
        }

        val place = AlarmStore.place(this)
        if (place == null || !AlarmStore.isActivePersisted(this)) {
            stopSelf(); return START_NOT_STICKY
        }
        lat = place.first; lon = place.second
        radius = maxOf(place.third, MIN_RADIUS)

        try {
            startInForeground()
        } catch (e: Exception) {
            // Android no dejó iniciar en primer plano (p. ej. reinicio en segundo plano):
            // la geovalla de respaldo sigue activa
            stopSelf(); return START_NOT_STICKY
        }

        if (wakeLock == null) {
            wakeLock = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoAlarma::tracking")
                .apply { setReferenceCounted(false); acquire(12 * 60 * 60 * 1000L) }
        }
        client = LocationServices.getFusedLocationProviderClient(this)
        near = null
        if (!applyMode(true)) {
            AlarmStore.setActive(this, false)
            stopSelf(); return START_NOT_STICKY
        }
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun applyMode(wantNear: Boolean): Boolean {
        if (near == wantNear) return true
        return try {
            near = wantNear
            client.removeLocationUpdates(callback)
            val req = if (wantNear)
                LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 2000L)
                    .setMinUpdateIntervalMillis(1000L).build()
            else
                LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 10000L)
                    .setMinUpdateIntervalMillis(5000L).build()
            client.requestLocationUpdates(req, callback, Looper.getMainLooper())
            true
        } catch (e: SecurityException) { false }
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Seguimiento del destino", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 3, Intent(this, TrackingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 4, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Geo-Alarma activa")
            .setContentText("Te aviso cuando llegues a tu destino")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Desactivar", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        else
            startForeground(NOTIF_ID, n)
    }

    override fun onDestroy() {
        try { if (::client.isInitialized) client.removeLocationUpdates(callback) } catch (e: Exception) { }
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
