package com.example.geoalarm

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

// Servicio en primer plano (tipo "location"): vigila TODAS las alarmas activas con GPS aunque
// estés en otra app, navegando o con la pantalla apagada. Cada alarma suena por separado.
class TrackingService : Service() {
    companion object {
        const val ACTION_STOP = "STOP_TRACKING"
        private const val CHANNEL = "tracking"
        private const val NOTIF_ID = 2
        const val MIN_RADIUS = 30f                  // por debajo de esto el GPS no es fiable
        private const val MAX_ACCURACY = 100f       // se ignoran lecturas peores que 100 m

        fun start(ctx: Context) =
            ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java))

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, TrackingService::class.java)) }

        // Aplica cambios en la lista de alarmas: sin alarmas activas se apaga; si no, recarga la lista
        fun refresh(ctx: Context) {
            try {
                if (AlarmStore.activeAlarms(ctx).isEmpty()) stop(ctx) else start(ctx)
            } catch (e: Exception) { }
        }
    }

    private lateinit var client: FusedLocationProviderClient
    private var wakeLock: PowerManager.WakeLock? = null
    private var near: Boolean? = null
    private var alarms = listOf<Alarm>()

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val d = FloatArray(1)
            val due = LinkedHashSet<String>()
            var minDist = Float.MAX_VALUE
            for (loc in result.locations) {
                for (a in alarms) {
                    Location.distanceBetween(loc.latitude, loc.longitude, a.lat, a.lon, d)
                    if (d[0] < minDist) minDist = d[0]
                    if (loc.accuracy <= MAX_ACCURACY && d[0] <= maxOf(a.radius, MIN_RADIUS)) due += a.id
                }
            }
            var fired = false
            for (id in due) if (AlarmTrigger.fire(this@TrackingService, id)) fired = true
            if (fired) {
                alarms = AlarmStore.activeAlarms(this@TrackingService)
                if (alarms.isEmpty()) { stopSelf(); return }   // ya no queda nada que vigilar
                updateNotification()
            }
            // Lejos de todas: GPS más espaciado (ahorra batería). Cerca de alguna: GPS cada 2 s
            val wantNear = if (near == true) minDist < 3000f else minDist < 2000f
            applyMode(wantNear)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            AlarmStore.activeAlarms(this).forEach { GeofenceHelper.remove(this, it.id) }
            AlarmStore.deactivateAll(this)
            stopSelf()
            return START_NOT_STICKY
        }

        alarms = AlarmStore.activeAlarms(this)
        // Siempre se pasa a primer plano primero (Android lo exige tras startForegroundService)
        try {
            startInForeground()
        } catch (e: Exception) {
            // Android no dejó iniciar en primer plano (p. ej. reinicio en segundo plano):
            // las geovallas de respaldo siguen activas
            stopSelf(); return START_NOT_STICKY
        }
        if (alarms.isEmpty()) { stopSelf(); return START_NOT_STICKY }

        if (wakeLock == null) {
            wakeLock = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoAlarma::tracking")
                .apply { setReferenceCounted(false); acquire(12 * 60 * 60 * 1000L) }
        }
        client = LocationServices.getFusedLocationProviderClient(this)
        near = null
        if (!applyMode(true)) {
            // Permiso de ubicación revocado: no se puede vigilar
            AlarmStore.deactivateAll(this)
            stopSelf(); return START_NOT_STICKY
        }
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun applyMode(wantNear: Boolean): Boolean {
        if (near == wantNear) return true
        return try {
            near = wantNear
            client.removeLocationUpdates(callback)
            val req = if (wantNear)
                LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 2000L)
                    .setMinUpdateIntervalMillis(1000L).build()
            else
                LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 10000L)
                    .setMinUpdateIntervalMillis(5000L).build()
            client.requestLocationUpdates(req, callback, Looper.getMainLooper())
            true
        } catch (e: SecurityException) { false }
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 3, Intent(this, TrackingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 4, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val text = when (alarms.size) {
            0 -> "Sin alarmas activas"
            1 -> "Te aviso al llegar a ${alarms[0].name}"
            else -> "Vigilando ${alarms.size} lugares"
        }
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Geo-Alarma activa")
            .setContentText(text)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Desactivar todas", stop).build())
            .setOngoing(true)
            .build()
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Seguimiento del destino", NotificationManager.IMPORTANCE_LOW)
        )
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        else
            startForeground(NOTIF_ID, n)
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    override fun onDestroy() {
        try { if (::client.isInitialized) client.removeLocationUpdates(callback) } catch (e: Exception) { }
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
