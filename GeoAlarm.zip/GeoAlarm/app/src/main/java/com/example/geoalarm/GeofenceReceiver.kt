package com.example.geoalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent

class GeofenceReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) return
        if (event.geofenceTransition != Geofence.GEOFENCE_TRANSITION_ENTER) return
        var fired = false
        event.triggeringGeofences?.forEach {
            if (AlarmTrigger.fire(context, it.requestId)) fired = true   // el requestId es el id de la alarma
        }
        if (fired) TrackingService.refresh(context)   // si no quedan alarmas activas, apaga el GPS
    }
}
