package com.example.geoalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import com.google.android.gms.location.LocationServices

class GeofenceReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) return
        if (event.geofenceTransition == Geofence.GEOFENCE_TRANSITION_ENTER) {
            ContextCompat.startForegroundService(
                context, Intent(context, AlarmService::class.java)
            )
            // La alarma suena una sola vez: se desactiva al llegar
            LocationServices.getGeofencingClient(context).removeGeofences(listOf("destino"))
            AlarmStore.setActive(context, false)
        }
    }
}
